#ifndef USUARIO_H
#define USUARIO_H

void registroUsuario(const char* cedula, const char* contrasena);
	
int validacionUsuario(const char* cedula, const char* contrasena);

#endif
